# -*- coding: utf-8 -*-

import empro.toolkit.adv as adv

def main():
	path=r"C:/Users/DELL/OneDrive/Documents/ADS/Patch antenna_wrk"
	lib=r"Patch antenna_lib"
	subst=r"Patch antenna_lib/substrate1.subst"
	substlib=r"Patch antenna_lib"
	substname=r"substrate1"
	cell=r"Patch antenna"
	view=r"layout"
	libS3D=r""
	varDictionary={}
	exprDictionary={}
	adv.loadDesign(path=path, lib=lib, subst=subst, substlib=substlib, substname=substname, cell=cell, view=view, libS3D=libS3D, var_dict=varDictionary, expr_dict=exprDictionary)
